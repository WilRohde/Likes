function like(name, ptr) {
    var elements = document.getElementsByClassName(name);
    var element = elements[ptr];
    var count = parseInt(element.innerText);
    count ++;
    element.innerText = count + " Like(s)";
}
// this probably wasn't necessary but i was curious
// about how to do it. this was useful:
// https://www.thoughtco.com/display-none-vs-visibility-hidden-3466884
function changePart(part) {
    var part1 = document.getElementsByClassName("container")[0].getElementsByClassName("part-1")[0];
    var part2 = document.getElementsByClassName("container")[0].getElementsByClassName("part-2")[0];
    if (part=="1") {
        part1.hidden = false;
        part2.hidden = true;
        part2.setAttribute("style","display: none");
    }
    else if (part=="2") {
        part1.hidden = true;
        part2.hidden = false;
        part2.setAttribute("style","display: flex");
    }
}